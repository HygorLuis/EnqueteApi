﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using EnqueteApi.Base;
using EnqueteApi.Models;

namespace EnqueteApi.Repository
{
    public class EnqueteRepository : BaseConnection
    {
        public Enquete BuscarEnquete(long id, bool visualizacao)
        {
            var enquete = new Enquete();
            var opcoesDt = new DataTable();
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.CommandText = $"SELECT * FROM Enquete WHERE Id = {id};";
                    var dr = sqlCommand.ExecuteReader();

                    if (!dr.HasRows) return null;
                    dr.Read();
                    enquete.Id = long.Parse(dr["Id"].ToString());
                    enquete.Questao = dr["Questao"].ToString();
                    enquete.QtdVisualizacao = visualizacao ? long.Parse(dr["QtdVisualizacao"].ToString()) : (long?)null;
                    dr.Close();

                    sqlCommand.CommandText = $"SELECT * FROM Opcoes WHERE IdEnquete = {id};";
                    using (var dataAdapter = new SqlDataAdapter())
                    {
                        dataAdapter.SelectCommand = sqlCommand;
                        dataAdapter.Fill(opcoesDt);
                    }
                }
                connection.Close();
            }

            enquete.Opcoes = new List<Opcoes>(opcoesDt.AsEnumerable().Select(o => new Opcoes
            {
                Id = long.Parse(o["Id"].ToString()),
                Descricao = o["Descricao"].ToString(),
                QtdVoto = visualizacao ? long.Parse(o["QtdVoto"].ToString()) : (long?)null
            }));

            return enquete;
        }

        public long SalvarEnquete(Enquete enquete)
        {
            long id;
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.Transaction = connection.BeginTransaction();
                    sqlCommand.CommandText = "INSERT INTO Enquete VALUES (@enquete, @qtd); SELECT SCOPE_IDENTITY();";
                    sqlCommand.Parameters.AddWithValue("@enquete", enquete.Questao);
                    sqlCommand.Parameters.AddWithValue("@qtd", 0);
                    id = long.Parse(sqlCommand.ExecuteScalar().ToString());

                    enquete.Opcoes.ForEach(x =>
                    {
                        sqlCommand.CommandText = $"INSERT INTO Opcoes VALUES ('{x.Descricao}', 0, {id});";
                        sqlCommand.ExecuteNonQuery();
                    });
                    sqlCommand.Transaction.Commit();
                }
                connection.Close();
            }

            return id;
        }

        public void SalvarVisualizacaoEnquete(long id)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.Transaction = connection.BeginTransaction();

                    sqlCommand.CommandText = $"UPDATE Enquete SET QtdVisualizacao = QtdVisualizacao + @qtd WHERE Id = {id};";
                    sqlCommand.Parameters.AddWithValue("@qtd", 1);
                    sqlCommand.ExecuteNonQuery();

                    sqlCommand.Transaction.Commit();
                }
                connection.Close();
            }
        }

        public bool SalvarVoto(long id)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (var sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.Transaction = connection.BeginTransaction();
                    sqlCommand.CommandText = $"SELECT * FROM Opcoes WHERE Id = {id};";
                    var dr = sqlCommand.ExecuteReader();

                    if (!dr.HasRows) return false;
                    dr.Close();

                    sqlCommand.CommandText = $"UPDATE Opcoes SET QtdVoto = QtdVoto + @qtd WHERE Id = {id}";
                    sqlCommand.Parameters.AddWithValue("@qtd", 1);
                    sqlCommand.ExecuteNonQuery();
                    sqlCommand.Transaction.Commit();
                }
                connection.Close();
            }

            return true;
        }
    }
}