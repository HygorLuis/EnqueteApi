﻿using System;
using EnqueteApi.Models;
using EnqueteApi.Repository;

namespace EnqueteApi.Service
{
    public class EnqueteService
    {
        private EnqueteRepository _enqueteRepository;

        public EnqueteService()
        {
            _enqueteRepository = new EnqueteRepository();
        }
        public Enquete BuscarEnquete(long id)
        {
            try
            {
                var enquete = _enqueteRepository.BuscarEnquete(id, false);
                if (enquete == null) return null;
                _enqueteRepository.SalvarVisualizacaoEnquete(enquete.Id);

                return enquete;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public long SalvarEnquete(Enquete enquete)
        {
            try
            {
                return _enqueteRepository.SalvarEnquete(enquete);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public Enquete BuscarVisualizacaoEnquete(long id)
        {
            try
            {
                return _enqueteRepository.BuscarEnquete(id, true);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool SalvarVoto(long id)
        {
            try
            {
                return _enqueteRepository.SalvarVoto(id);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}