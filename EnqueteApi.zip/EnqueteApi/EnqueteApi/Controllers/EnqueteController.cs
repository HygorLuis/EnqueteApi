﻿using System.Net;
using System.Web.Http;
using System.Web.Http.Results;
using EnqueteApi.Models;
using EnqueteApi.Service;

namespace EnqueteApi.Controllers
{
    [RoutePrefix("Enquete")]
    public class EnqueteController : ApiController
    {
        private EnqueteService _enqueteServico;

        public EnqueteController()
        {
            _enqueteServico = new EnqueteService();
        }

        [HttpGet]
        [Route("poll/{id:long}")]
        public NegotiatedContentResult<Enquete> GetEnquete(long id)
        {
            var enquete = _enqueteServico.BuscarEnquete(id);

            return enquete == null ? Content(HttpStatusCode.NotFound, (Enquete)null) : Content(HttpStatusCode.OK, enquete);
        }

        [Route("poll")]
        public long Post(Enquete enquete)
        {
            return _enqueteServico.SalvarEnquete(enquete);
        }

        [Route("poll/{id:long}/vote")]
        public IHttpActionResult Post(long id)
        {
            return _enqueteServico.SalvarVoto(id) ? (IHttpActionResult)Ok() : NotFound();
        }

        [HttpGet]
        [Route("poll/{id:long}/stats")]
        public NegotiatedContentResult<Enquete> GetEstatisticas(long id)
        {
            var enquete = _enqueteServico.BuscarVisualizacaoEnquete(id);

            return enquete == null || enquete.Id == 0 ? Content(HttpStatusCode.NotFound, new Enquete()) : Content(HttpStatusCode.OK, enquete);
        }
    }
}
