﻿using System.Collections.Generic;

namespace EnqueteApi.Models
{
    public class Enquete
    {
        public long Id { get; set; }
        public string Questao { get; set; }
        public List<Opcoes> Opcoes { get; set; }
        public long? QtdVisualizacao { get; set; }
    }
}