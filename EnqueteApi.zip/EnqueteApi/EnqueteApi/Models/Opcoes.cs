﻿namespace EnqueteApi.Models
{
    public class Opcoes
    {
        public long Id { get; set; }
        public string Descricao { get; set; }
        public long? QtdVoto { get; set; }
    }
}