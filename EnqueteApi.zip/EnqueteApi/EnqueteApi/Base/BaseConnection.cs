﻿namespace EnqueteApi.Base
{
    public class BaseConnection
    {
        //public static string ConnectionString = "Server=localhost; Data Source=DESKTOP-IABMA0P\\SQLEXPRESS; Initial Catalog=EnqueteDB; User ID=hygor; Password=123";
        public static string ConnectionString = "Server=localhost; Initial Catalog=EnqueteDB; User ID=hygor; Password=123";
    }
}